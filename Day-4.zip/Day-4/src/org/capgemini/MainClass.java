package org.capgemini;

public class MainClass {

	public static void main(String[] args) {
	
		Address add=new Address(12,"North Street","Mumbai");
		
		Account account=new Account(1001, "Tom", 23000,add);
		Account account1=new Account(1023, "Jerry", 53000);
		
		
		
		
		try {
			Account acc=(Account)account.clone();
			account.getAddress().setDoorNo(100);;
			
			System.out.println(acc);
			System.out.println(account);
			
			//System.out.println(acc==account);
			
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
