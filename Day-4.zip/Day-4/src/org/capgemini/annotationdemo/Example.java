package org.capgemini.annotationdemo;

import java.lang.annotation.Annotation;

public class Example {

	public static void main(String[] args) {
		
		
		 
		
		Package pack= Package.getPackage("java.lang.annotation");
		
		Employee emp=new Employee();
		
		
		 
	//	 for(Package p:pack){
			 Annotation[]  anno= emp.getClass().getAnnotations();
					 
					 //pack.getAnnotations();
			 System.out.println(anno.getClass());
			 System.out.println(anno.length + "-->" +pack);
		// }
	}

}
