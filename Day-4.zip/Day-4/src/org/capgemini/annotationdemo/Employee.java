package org.capgemini.annotationdemo;

@AuthorInfo(authorName="viji",age=29)
public class Employee {
	
	
	
	@AuthorInfo(authorName="Tom",age=23)
	public void getEmpDetails(){
		
	}
	
	
	

}
