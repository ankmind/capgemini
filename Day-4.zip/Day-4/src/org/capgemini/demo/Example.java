package org.capgemini.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Example {

	public static void main(String[] args) {
	Example ex=new Example();
	System.out.println(ex.calculate());
	
	System.out.println("Program Terminates");
	}
	
	
	
	public int calculate(){

		String num1="100",num2="0";
		
		int ans;
		try{
			File file=new File("");
			FileReader fr=new FileReader(file);
			int n1=Integer.parseInt(num1);
			int n2=Integer.parseInt(num2);
			
			try{
		ans=n1/n2;
		System.out.println("Answer : " +ans);
			}catch (NullPointerException e) {
				//System.out.println(e.getMessage());
				e.printStackTrace();
				return 0;
			}
			
		//System.exit(0);
		
		}//jdk 1.7
		/*catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}*/
		catch(ArithmeticException | NumberFormatException e){
			
		}
		/*catch (Exception e) {
			System.out.println(e.getMessage());
		}*/
		
		/*catch (ArithmeticException e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
			return 0;
		}
		catch (NumberFormatException e) {
			System.out.println(e.getMessage());
		}*/		
		finally{
			System.out.println("Finally block");
			return 11;
		}
		
		
		
		
		//return 12;
	}
	

}
