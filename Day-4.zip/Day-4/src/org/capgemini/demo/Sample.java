package org.capgemini.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Sample {

	public static void main(String[] args) {
		try{
		File file=new File("");
		FileInputStream fin=new FileInputStream(file);
		}catch(FileNotFoundException ex){
			
		}
	}

}
