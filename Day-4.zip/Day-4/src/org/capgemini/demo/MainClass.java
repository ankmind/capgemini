package org.capgemini.demo;

import java.io.FileNotFoundException;
import java.sql.SQLException;

public class MainClass {

	public static void main(String[] args) {
		Parent parent=new Parent();
		Child child=new Child();
		
		try {
			parent.show();
		} catch (NumberFormatException | FileNotFoundException
				| ArithmeticException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			child.show();
		} catch (FileNotFoundException | NullPointerException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
