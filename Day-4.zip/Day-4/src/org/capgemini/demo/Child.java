package org.capgemini.demo;

import java.io.FileNotFoundException;
import java.sql.SQLException;

public class Child extends Parent {

	@Override
	public void show() throws Exception,FileNotFoundException,SQLException, NullPointerException{
		System.out.println("Child Class method");
	}
}
