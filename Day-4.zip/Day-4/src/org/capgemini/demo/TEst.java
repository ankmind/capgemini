package org.capgemini.demo;

public class TEst {

	public static void main(String[] args) {
		/*System.out.println(1);
        assert false;
        System.out.println(2);*/
		
		int value=10;
		assert(value>=18):"�Not�valid";
		System.out.println("value�is�"+value);	}

}
