package org.capgemini.demo;

public class Example2 {

	public static void main(String[] args) {
		
		
		Demo demo=new Demo();
		
		try{
		demo.showDetails();
		}catch(NullPointerException|NumberFormatException|ArithmeticException ex){
			System.out.println(ex.getMessage());
		}
		
		
		System.out.println("Program Terminates");
		
	}

}
