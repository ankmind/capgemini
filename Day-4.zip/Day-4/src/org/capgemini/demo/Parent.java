package org.capgemini.demo;

import java.io.FileNotFoundException;
import java.sql.SQLException;

public class Parent {
	
	public void show() throws Exception,FileNotFoundException,SQLException, ArithmeticException, NumberFormatException{
		System.out.println("Parent Class Method");
	}

}
