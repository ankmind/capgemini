package org.capgemini.demo;

public class ExDemo {

	public static void main(String[] args) {
		
		
		int num1=100,num2=0;
		int ans=0;
		
		try{
		if(num2==0)
			throw new ArithmeticException("Number divisable by Zero : Errror!");
		else
			ans=num1/num2;
		}catch(ArithmeticException ex){
			System.out.println(ex.getMessage());
		}
	}

}
