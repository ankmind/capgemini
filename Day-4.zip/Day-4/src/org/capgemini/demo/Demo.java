package org.capgemini.demo;

public class Demo {
	
	public void showDetails() throws NumberFormatException,NullPointerException,ArithmeticException{
		String str=null;
		//System.out.println(str);
		int ans=100 + Integer.parseInt(str);
		
		int result=100/Integer.parseInt(str);
	}

}
