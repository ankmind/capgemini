package org.capgemini;

public class Account implements Cloneable {
	
	private int acctNo;
	private String accName;
	private double balance;
	private Address address;
	
	public Account(){}
	
	public Account(int acctNo, String accName, double balance) {
		super();
		this.acctNo = acctNo;
		this.accName = accName;
		this.balance = balance;
	}
	
	
	
	public Account(int acctNo, String accName, double balance, Address address) {
		super();
		this.acctNo = acctNo;
		this.accName = accName;
		this.balance = balance;
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(int acctNo) {
		this.acctNo = acctNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	/*@Override
	public String toString() {
		return "Account [acctNo=" + acctNo + ", accName=" + accName
				+ ", balance=" + balance + "]";
	}*/
	
	

	@Override
	public Object clone() throws CloneNotSupportedException {
		
		//Deep Copy
		
		Account account=new Account();
		account.setAcctNo(this.getAcctNo());
		account.setAccName(this.getAccName());
		account.setBalance(this.getBalance());
		
		Address address=new Address();
		address.setDoorNo(this.getAddress().getDoorNo());
		address.setStName(this.getAddress().getStName());
		address.setCity(this.getAddress().getCity());
		
		account.setAddress(address);
		
		
		return account;
	}

	@Override
	public String toString() {
		return "Account [acctNo=" + acctNo + ", accName=" + accName
				+ ", balance=" + balance + ", address=" + address + "]";
	}
	
	
	

}
