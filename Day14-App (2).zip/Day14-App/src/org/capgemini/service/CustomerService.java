package org.capgemini.service;

import java.sql.Connection;
import java.util.List;

import org.capgemini.model.Customer;
import org.capgemini.model.DBConnection;
import org.capgemini.model.Login;

public interface CustomerService {
	public boolean isValidUser(Login login,Connection dbConnection);
	public void saveCustomer(Customer customer,Connection dbConnection);
	public List<Customer> getAllCustomers(Connection dbConnection);
	public int deleteCustomer(int custId, Connection dbConnection);

}
