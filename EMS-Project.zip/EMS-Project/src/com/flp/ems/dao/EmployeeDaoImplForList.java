package com.flp.ems.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.ems.domain.Employee;

public class EmployeeDaoImplForList implements IemployeeDao{
	
	static ArrayList<Employee> lst=new ArrayList<Employee>();
	static int empId=0;

	@Override
	public void addEmployee(Employee employee) {
		empId++;
		employee.setEmployeeId(empId);
		lst.add(employee);
		
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return lst;
	}

}
