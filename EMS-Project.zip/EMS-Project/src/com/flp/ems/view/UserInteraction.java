package com.flp.ems.view;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.flp.ems.domain.Department;
import com.flp.ems.domain.Employee;
import com.flp.ems.domain.Project;
import com.flp.ems.util.Validate;

public class UserInteraction {
	static Scanner sc;
	
	public Employee addEmployee(){
		
		sc=new Scanner(System.in);
		Employee emp=new Employee();
		String kinId;
		boolean flag=false;
		String empName;
		//to validate EmpName
				do{
				System.out.println("Enter Employee Name:");
				empName=sc.nextLine();
				
				flag=Validate.isValidEmployeeName(empName);
				if(!flag)
					System.out.println("Invalid Employee Name!!!!");
				
				}while(!flag);
				emp.setEmpName(empName);
				
				
				
				//to validate Address
				String address;
				do{
				System.out.println("Enter Employee Address:");
				address=sc.nextLine();
				
				flag=Validate.isValidAddress(address);
				if(!flag)
					System.out.println("Invalid Address!");
				
				}while(!flag);
				emp.setAddress(address);
		
		//to validate kinid
		kinId=getValidKinId();
		emp.setKinId(kinId);
		
		
		//to validate Email
				emp.setEmailId(getValidEmail());
	
		
				String empDob;
				//to validate Emails
						do{
						System.out.println("Enter Employee Date of Birth:");
						empDob=sc.next();
						
						flag=Validate.isValidDate(empDob);
						if(!flag)
							System.out.println("Invalid Date Format(dd-MMM-yyyy)!");
						
						}while(!flag);
						emp.setEmpdob(new Date(empDob));		
				
		
						
						String empDoj;
						//to validate Emails
								do{
								System.out.println("Enter Employee Date of Joining:");
								empDoj=sc.next();
								
								flag=Validate.isValidDate(empDoj);
								if(!flag)
									System.out.println("Invalid Date Format(dd-MMM-yyyy)!");
								
								}while(!flag);
								emp.setEmpdoj(new Date(empDoj));		
					
								
								String phoneno;
								System.out.println("Enter Employee Phone Number:");
								phoneno=sc.next();
								emp.setPhoneNo(phoneno);
								
								
								Department department;
								do{
									
								department=getDepartment();
								if(department==null)
									System.out.println("Invalid Deprtment Id!");
								}while(department==null);
								
								emp.setDepartment(department);
								
								
								
								
								//Scan list of projects
								List<Project> projects;
								do{
									projects=getProjects();
								
								if(projects.isEmpty())
									System.out.println("Invalid Project List!");
								}while(projects.isEmpty());
								
								emp.setProject(projects);
								
								
								//sc.close();
		return emp;
	}
	
	
	
	public static String getValidKinId(){
		//to validate kinid
		sc=new Scanner(System.in);
		String kinId;
		boolean flag=false;
				do{
				System.out.println("Enter Employee KinId:");
				kinId=sc.next();
				
				flag=Validate.isValidKinId(kinId);
				if(!flag)
					System.out.println("Invalid KinId!!!!");
				
				}while(!flag);
				
				
				
				
				
				//sc.close();
		return  kinId;
	}
	
	public static String getValidEmail(){
		String email;
		boolean flag=false;
		sc=new Scanner(System.in);
		//to validate Emails
				do{
				System.out.println("Enter Employee Email Id:");
				email=sc.next();
				
				flag=Validate.isValidEmail(email);
				if(!flag)
					System.out.println("Invalid Email!");
				
				}while(!flag);
				//sc.close();
				return email;
	}
	
	public static List<Department> getAllDepartments(){
		List<Department> departments=new ArrayList<Department>();
		departments.add(new Department(101, "TDI", "Technology Developement And Integration"));
		departments.add(new Department(102, "Cards", "All type of cards"));
		departments.add(new Department(103, "Testing", "Testing Domain"));
		departments.add(new Department(104, "L&C", "Learning And Culture"));
		departments.add(new Department(105, "Payments", "All Payment"));
		departments.add(new Department(106, "PEN", "INfra management"));
		
		return departments;
	}
	
	
	public static Department getDepartment(){
		
		Department department=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Choose The Department:");
		
		for(Department dept:getAllDepartments()){
			System.out.println(dept);
		}
		System.out.println("Enter Deperment Id:");
		int deptId=sc.nextInt();
		
		for(Department dept:getAllDepartments()){
			if(dept.getDepartmentId()==deptId){
				department=dept;
			break;
			}
		}
		
		return department;
	}
	
	
	
	
	
	
	
	public static List<Project> getAllProjects(){
		List<Project> projects=new ArrayList<Project>();
		projects.add(new Project(1, "Morgan", "Morgan"));
		projects.add(new Project(2, "Barclays", "Barclays"));
		projects.add(new Project(3, "HSBC", "HSBC"));
		projects.add(new Project(4, "Scope", "Scope"));
		projects.add(new Project(5, "TRansUnion", "TRansUnion"));
		projects.add(new Project(6, "CITI", "CITI"));
		
		return projects;
	}
	
	
	public List<Project> getProjects(){
		List<Project> projects=new ArrayList<Project>();
		String choice;
		Scanner sc=new Scanner(System.in);
		
		do{
			Project myproject=null;
			System.out.println("Choose Project:");
			for(Project project: getAllProjects())
				System.out.println(project.getProjectId() +"\t" + project.getProjectName() +"\t" + project.getDescription());
			
			System.out.println("Choose Project ID:");
			int projectId=sc.nextInt();
			
			for(Project project: getAllProjects()){
				if(projectId==project.getProjectId())
					myproject=project;
			}
			
			
			//Scan Departmet for that project
			System.out.println("Choose Department For this Project:");
			Department department=getDepartment();
			myproject.setDepartment(department);
			
			
			projects.add(myproject);
			System.out.println("Do you want to enter more Project Details?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		
		return projects;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
