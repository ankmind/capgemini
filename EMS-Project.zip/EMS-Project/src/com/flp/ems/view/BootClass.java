package com.flp.ems.view;

import java.util.ArrayList;
import java.util.Scanner;

import com.flp.ems.domain.Employee;
import com.flp.ems.service.EmployeeServiceImpl;
import com.flp.ems.service.IEmployeeService;

public class BootClass {
	
	

	public static void main(String[] args) {
		
		menuSelection();

	}

	
	public static void menuSelection(){
		
		Scanner sc=new Scanner(System.in);
		int option;
		String choice;
		
		do{
		System.out.println("1.Add Employee");
		System.out.println("2.Modify Employee");
		System.out.println("3.Remove Employee");
		System.out.println("4.Search Employee");
		System.out.println("5.Get All Employee");
		System.out.println("6.Exit");
		System.out.println("Enter your option:");
		option=sc.nextInt();
		UserInteraction userInteract=new UserInteraction();
		EmployeeServiceImpl empService=new EmployeeServiceImpl();
		
		
			switch(option){
				case 1:
				{
					Employee emp=userInteract.addEmployee();
					
					while(!empService.isUniqueKinId(emp.getKinId())){
						
						System.out.println("Sorry! KinId Already Exists.");
						String ekinid=UserInteraction.getValidKinId();
						emp.setKinId(ekinid);
						
					}
					
					while(!empService.isUniqueEmailId(emp.getEmailId())){
						
						System.out.println("Sorry! Email Already Exists.");
						String eemail=UserInteraction.getValidEmail();
						emp.setKinId(eemail);
						
					}
					
					empService.addEmployee(emp);	
						
					System.out.println(emp);
					break;
				}
				case 6:
				{
					System.exit(0);
				}
			}
		
			
			System.out.println("Do you want to Continue?[y/n]");
			choice=sc.next();
		
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		
		//sc.close();
	}
}
