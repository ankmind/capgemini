package com.flp.ems.service;

import java.util.List;

import com.flp.ems.dao.EmployeeDaoImplForList;
import com.flp.ems.dao.IemployeeDao;
import com.flp.ems.domain.Employee;
import com.flp.ems.view.UserInteraction;

public class EmployeeServiceImpl implements IEmployeeService{

	private  IemployeeDao empDao=new EmployeeDaoImplForList();
	//private UserInteraction userInput=new UserInteraction();
	
	@Override
	public void addEmployee(Employee employee) {
		
		empDao.addEmployee(employee);
	}
	
	//Check KinId
	public  boolean isUniqueKinId(String kinId){
		boolean flag=true;
		List<Employee> employees=getAllEmployees();
		
		if (employees.isEmpty())
			flag=true;
		else
		{
			for(Employee emp : employees){
				if(emp.getKinId().equals(kinId)){
					flag=false;
					break;
				}
			}
		}
		
		return flag;
	}
	
	
	
	//Check EmailID
		public  boolean isUniqueEmailId(String emailId){
			boolean flag=true;
			List<Employee> employees=getAllEmployees();
			
			if (employees.isEmpty())
				flag=true;
			else
			{
				for(Employee emp : employees){
					if(emp.getEmailId().equals(emailId)){
						flag=false;
						break;
					}
				}
			}
			
			return flag;
		}


	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return empDao.getAllEmployees();
	}

}
