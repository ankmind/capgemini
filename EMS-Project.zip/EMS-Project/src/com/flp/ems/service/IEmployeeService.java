package com.flp.ems.service;

import java.util.ArrayList;
import java.util.List;

import com.flp.ems.domain.Employee;

public interface IEmployeeService {
	
	public void addEmployee(Employee employee );
	
	public List<Employee> getAllEmployees();

}
