package com.flp.ems.util;

public class Validate {
	
	public static boolean isValidKinId(String kinId){
		return kinId.matches("G\\d{8}");
	}
	
	public static boolean isValidEmail(String email){
		return email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}
	
	public static boolean isValidEmployeeName(String empName){
		return empName.matches("[A-Z][a-zA-Z ]*");
	}
	

	public static boolean isValidAddress(String address){
		return address.matches("[a-zA-Z0-9/,\\-#. ]+");
	}
	
	public static boolean isValidDate(String myDate){
		return myDate.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][089]\\d{2}");
	}
	

}
