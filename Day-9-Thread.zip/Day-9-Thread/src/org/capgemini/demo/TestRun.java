package org.capgemini.demo;

public class TestRun {

	public static void main(String[] args) {
		
		Runnable r=new Runnable() {
			
			@Override
			public void run() {
				for(int i=0;i<=100;i++)
					System.out.println(Thread.currentThread().getName() + "->>"+ i);

			}
		};
		
		Thread t2=new Thread(){
			public void run(){
				String yname="Capgemini";
				for(int i=0;i<yname.length();i++){
					for(int j=0;j<=i;j++){
					System.out.print(yname.charAt(j) +"  ");
					}
					System.out.println();
				}
				System.out.println();
			}
		};
		
		
		Thread t1=new Thread(r);
		t1.start();
		t2.start();
		
	}

}
