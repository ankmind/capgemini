package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		
		ThreadRunnable t1=new ThreadRunnable("Capgemini");
		
		
		ThreadRunnable t2=new ThreadRunnable("Barclays");
		
		//new State
		Thread thread1=new Thread(t1,"thread->1");
		//Runnable
		//Running
		thread1.start();
		
		Thread thread2=new Thread(t2,"thread->2");
		thread2.start();
		
		
		
		//dead t1,t2
	}

}
