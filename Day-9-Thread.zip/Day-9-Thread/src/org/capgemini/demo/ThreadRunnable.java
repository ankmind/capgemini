package org.capgemini.demo;

public class ThreadRunnable implements Runnable {
	
	private String yname;

	
	public ThreadRunnable(String yname){
		this.yname=yname;
	}
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName());
		printmyName();
		
	}

	
	public void printmyName(){

		for(int i=0;i<yname.length();i++){
			for(int j=0;j<=i;j++){
			System.out.print(yname.charAt(j) +"  ");
			
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			}
			System.out.println();
		}
		System.out.println();
	}
	
}
