package org.capgemini.demo;

public class TestMain {

	public static void main(String[] args) {
		
		MyThread t1=new MyThread("first");
		MyThread t2=new MyThread("second");
		MyThread t3=new MyThread("third");
		System.out.println("CurrentThread:"+Thread.currentThread().getName());
		t3.setPriority(Thread.MAX_PRIORITY);
		t1.setPriority(Thread.MIN_PRIORITY);
		t1.start();
		
		/*try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		t2.start();
		
		Thread.yield();
		
		/*try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		t3.start();
		
	
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		System.out.println(t3.getPriority());
		
		
		//t1.run();
	}

}
