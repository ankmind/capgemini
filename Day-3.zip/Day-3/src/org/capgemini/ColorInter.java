package org.capgemini;

public interface ColorInter extends Shape,GrapicsInter {

	public void getColor();
	void fillColor();
	
}
