package org.capgemini;

public interface GrapicsInter {
	
	void moveObject();
	void scrollObject();
	void drawShape();

}
