package org.capgemini;

public class Circle implements ColorInter {

	@Override
	public void drawShape() {
		System.out.println("PI" + PI);
	}

	@Override
	public void fillShape() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void moveObject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void scrollObject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getColor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

}
