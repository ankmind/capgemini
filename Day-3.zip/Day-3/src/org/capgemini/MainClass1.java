package org.capgemini;

public class MainClass1 {

	public static void main(String[] args) {
		
		MyAbstractClass obj=new MyAbstractClass() {
			
			@Override
			void show() {
			System.out.println("Show");	
			details();
			}
			
			void details(){
				System.out.println("Details");
			}
		};
		
		obj.nonAbstractMethod();
		obj.show();
		//obj.details();
		
	}

}
