package org.capgemini.wrapperDemo;

import java.util.Date;

public class TestWarpperClass {

	public static void main(String[] args) {
		
		
		int i=100;
		
		Integer obj=new Integer(i);
		
		Integer in=10;
		
		
		System.out.println(in.intValue());
		
		System.out.println(in);
		
		//Auto boxing
		
		
		
	System.out.println("Min : "+ Integer.MIN_VALUE);
	System.out.println("Max : "+ Integer.MAX_VALUE);
	System.out.println("Size : "+ Integer.SIZE);
	
	Date mydate=new Date();
	
	long val=mydate.getTime();
	
	
	System.out.println(new Date(val).getDate());
	
	
	}

}
