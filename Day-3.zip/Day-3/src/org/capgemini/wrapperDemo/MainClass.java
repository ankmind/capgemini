package org.capgemini.wrapperDemo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		/*
		Employee emp=new Employee(1001, "Tom", 3400);
		Employee emp1=new Employee(1001, "Tom", 3400);
		
		System.out.println(emp.equals(emp1));
		*/
		
		
		/*Attendance emp1=new Attendance(1001, "Tom", 23000, 23);
		
		Attendance emp2=new Attendance(1001, "Tom", 23000, 23);
		
		
		System.out.println(emp1.equals(emp2));
		
		*/
		
		
		
		Scanner sc=new Scanner(System.in);
		String empid;
		do{
		System.out.println("Enter Employee Id:");
		empid=sc.next();
		}while(!Utility.isValidEmpId(empid));
		
		
		Employee emp=new Employee();
		emp.setEmpId(empid);
		
		System.out.println(emp.getEmpId());
		
		
		
	}

}
