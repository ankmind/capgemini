package org.capgemini.wrapperDemo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SampleDate {

	public static void main(String[] args) {
		
		Date myDate=new Date();
		System.out.println(myDate);
		
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-MM-yyyy");
		
		System.out.println(myFormat.format(myDate).toUpperCase());
		
	}

}
