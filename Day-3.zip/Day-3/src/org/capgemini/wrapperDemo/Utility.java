package org.capgemini.wrapperDemo;

public class Utility {
	
	
	public static boolean isValidEmpId(String empid){
		return empid.matches("\\d{5}_(FS|TS)");
	}

}
