package org.capgemini.wrapperDemo;

public class Attendance extends Employee {
	
	private int noofDays;

	public Attendance(String empId,String empName,double salary,int days){
		super(empId,empName,salary);
		this.noofDays=days;
	}
	
	
	public int getNoofDays() {
		return noofDays;
	}

	public void setNoofDays(int noofDays) {
		this.noofDays = noofDays;
	}
	
	
	
	
	
	

}
