package org.capgemini.wrapperDemo;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Caldemo {

	public static void main(String[] args) {
		
		Calendar mydate=new GregorianCalendar();
		System.out.println(mydate.get(Calendar.YEAR));
		System.out.println(mydate);
		System.out.println(mydate.get(Calendar.YEAR));
		
		mydate.add(Calendar.MONTH, 10);
		
		System.out.println(mydate);
		System.out.println(mydate.get(Calendar.YEAR));
		
		
	}

}
