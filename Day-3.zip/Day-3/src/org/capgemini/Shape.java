package org.capgemini;

public interface Shape {

	void drawShape();
	public abstract void fillShape();
	
	public static final double PI=3.14;
	
}
