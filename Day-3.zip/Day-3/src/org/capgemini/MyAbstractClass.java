package org.capgemini;

public abstract class MyAbstractClass {
	
	abstract void show();
	public void nonAbstractMethod(){
		System.out.println("NoN Abstract Method");
	}
	

}
