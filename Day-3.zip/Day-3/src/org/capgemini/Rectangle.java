package org.capgemini;

public class Rectangle implements Shape,GrapicsInter{

	public void rectangeDetails(){
		System.out.println("Length:\n Width:");
	}
	
	
	@Override
	public void drawShape() {
		System.out.println("Draw Rectangle");
	}

	@Override
	public void fillShape() {
		System.out.println("Fill Rectangle");
		
	}

	@Override
	public void moveObject() {
		System.out.println("Moving Rectangle");
	}

	@Override
	public void scrollObject() {
		System.out.println("Scrolling Rectangle");
		
	}

}
