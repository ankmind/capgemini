package org.capgemini;

public class MainClass {

	public static void main(String[] args) {
		
		//Shape shape=new Rectangle();
		Rectangle shape=new Rectangle();
		
		shape.drawShape();
		shape.rectangeDetails();
		
		
		
		
		Shape shape2=new Shape() {
			
			@Override
			public void fillShape() {
			
				System.out.println("Annonymous Method");
			}
			
			@Override
			public void drawShape() {
				System.out.println("Annonymous Method");
			}
		};
		
		shape2.fillShape();
		shape2.drawShape();
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
