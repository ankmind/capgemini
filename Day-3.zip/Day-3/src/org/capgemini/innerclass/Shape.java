package org.capgemini.innerclass;

public interface Shape {
	
	void draw();
	
	interface Color extends Shape{
		void fillColor();
	}

}
