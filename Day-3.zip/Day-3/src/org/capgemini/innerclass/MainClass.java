package org.capgemini.innerclass;

public class MainClass {

	public static void main(String[] args) {
	
		
		OuterClass1.InnerClass in=new OuterClass1.InnerClass();
		
		in.nonStatic_Method();
		OuterClass1.InnerClass.static_Method();
		
		
		

	}

}
