package org.capgemini.innerclass;

public class OuterClass1 {
	
	static int mynum=100;
	
	
	static class InnerClass{
		int num=10;
		static int count=10;
		
		public void nonStatic_Method(){
			System.out.println("Non Static Method");
			System.out.println("Count:" + count);
			System.out.println("Num:" + num);
			System.out.println("MyNum:" + mynum);
		}
		
		
		public static void static_Method(){
			System.out.println("Non Static Method");
			System.out.println("Count:" + count);
			System.out.println("Num:" + mynum);
		}
	}

}
