package org.capgemini.innerclass;

public class OuterClass {
	
	
	int i=100;
	int num=10;
	
	public void show(){
		//Outer$inner.class
		
		class Inner{
			int i=50;
			int count=150;
			
			public void show(){
		/*		OuterClass out=new OuterClass();
				out.show();
		*/		System.out.println("NUm:" + num);
				System.out.println("Inner Class Method");
			}
			
			
		}
		
		Inner in=new Inner();
		in.show();
		
		
		System.out.println("Outer Class Method");
	}
	
	
	
	

}
