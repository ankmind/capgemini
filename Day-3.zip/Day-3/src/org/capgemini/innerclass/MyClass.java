package org.capgemini.innerclass;

public class MyClass implements Demo.DBConnection{

	@Override
	public void getConnection() {
		// TODO Auto-generated method stub
		
	}

}
