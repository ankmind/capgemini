package org.capgemini.innerclass;

public class TestClass {

	public static void main(String[] args) {
		
		
		OuterClass out=new OuterClass();
		System.out.println(out.i);
		out.show();
		
		
		/*OuterClass.inner in=out.new inner();
		System.out.println(in.i);
		System.out.println(in.count);
		in.show();
		*/
		
	}

}
