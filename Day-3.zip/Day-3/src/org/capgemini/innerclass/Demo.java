package org.capgemini.innerclass;


public class Demo {
	
	interface DBConnection{
		void getConnection();
	}


}
