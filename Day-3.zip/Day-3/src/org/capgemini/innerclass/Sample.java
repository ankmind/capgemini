package org.capgemini.innerclass;

public class Sample implements Shape.Color {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

}
