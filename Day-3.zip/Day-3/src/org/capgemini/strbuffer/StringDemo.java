package org.capgemini.strbuffer;

public class StringDemo {

	public static void main(String[] args) {
		
		StringBuffer stb=new StringBuffer("tom");
		
System.out.println(stb.length());
		
		System.out.println(stb.capacity());
		
		
		stb.append(" I am attending Java session!!!");
		
		
		System.out.println(stb.length());
		
		System.out.println(stb.capacity());
		
		
		
		
		
		
		
		
	}

}
