package org.capgemini.mytag;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MyDateFormat extends SimpleTagSupport{
	
	
	private String myFormat;
	
	

	public void setMyFormat(String myFormat) {
		this.myFormat = myFormat;
	}



	@Override
	public void doTag() throws JspException, IOException {
		
		JspWriter out=getJspContext().getOut();
		
		if (myFormat!=null)
		{
			SimpleDateFormat format=new SimpleDateFormat(myFormat);
			out.println(format.format(new Date()));
		}
		else{
		out.println(new Date());
		}
	}
	
	

}
