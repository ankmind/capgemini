package org.capgemini.mytag;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class GreetingsTag extends SimpleTagSupport{

	@Override
	public void doTag() throws JspException, IOException {
		
		StringWriter sw=new StringWriter();
		
		JspWriter out=getJspContext().getOut();
		getJspBody().invoke(sw);
		
		out.println("Hello! Good AfterNoon!! -->" + sw);
	}

	
	
	
}
