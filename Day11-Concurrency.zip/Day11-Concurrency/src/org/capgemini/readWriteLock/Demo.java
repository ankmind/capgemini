package org.capgemini.readWriteLock;

import java.util.concurrent.ConcurrentHashMap;

public class Demo {

	public static void main(String[] args) {
		
		ConcurrentHashMap<Integer, String> str=new ConcurrentHashMap<Integer, String>();
		
	}

}
