package org.capgemini.readWriteLock;

import java.util.HashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class MyBean {
	HashMap<Integer , String>  messages = new  HashMap<Integer , String>();

	/*
	 * TODO 1  : 
	 * comment : getData() method of this class is used by the Reader  threads and 
	 *           setData() nethod of this class is used by the Writer threads.
	 *           
	 *           Reader threads need the lock for reading purpose while Writer threads need 
	 *           the lock only for writing purpose. So here  ReentrantReadWriteLock  is used 
	 *           instead of  ReentrantLock. Because with this class we can get separate readLock 
	 *           which can be used  only for reading purpose and separate writeLock used for writing 
	 *           purpose. While we get a plain lock with the class ReentrantLock.
	 */
	
	private  boolean  fairnessFlag = true ;
	
	private  final    ReentrantReadWriteLock rwl = new ReentrantReadWriteLock(fairnessFlag);
	
	private final Lock readlock = rwl.readLock();
    private final Lock writelock = rwl.writeLock();
    
    /* 
     * TODO  2 : 
     * comment : Following function is used by the Reader thread to read the data.
     *           Hence works with readLock.
     */
    
    
    public String getData(int messageNumber) 
    {
    	 try{
    	      while(messages.size() == 0) ;
                   
    	      readlock.lock();
    	      
    	      if (messages.size() >= messageNumber)
    	          return messages.get(messageNumber);
    	      else
    	    	  return ("No message ready. ");
    	     }
          finally{
        	         
        	       if (readlock != null)
        	           readlock.unlock();
        	     
        	     } // end finally
    }
 
    /* 
     * TODO  3 : 
     * comment : Following function is used by the Writer thread to write the data.
     *           Hence works with writeLock.
     */
    
    public void setData(int messageNumber , String  message) 
    {
    	 try{
  	       	   writelock.lock();
         	   messages.put(messageNumber , message); 
             }
            finally{
          	       
          	       if (writelock != null)
          	       writelock.unlock();
          	      
          	     } // end finally
     }
    


}
