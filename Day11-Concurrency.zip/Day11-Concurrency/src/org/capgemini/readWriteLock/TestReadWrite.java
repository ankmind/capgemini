package org.capgemini.readWriteLock;

public class TestReadWrite {

final MyBean bean = new MyBean() ;
        
	
	public static void main(String[] args)
	{
		final MyBean bean = new MyBean() ;
        
		Writer  writerRunnable = new Writer(bean);
		
		Thread writer = new Thread(writerRunnable, "WriterThread1");
		
		Thread reader1 = new Thread(new  Reader(bean) , "Reader_1");
				
		Thread reader2 = new Thread(new Reader(bean), "Reader_2");
		
		writer.start() ;
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		reader1.start() ;
		reader2.start();
		System.out.println(Thread.currentThread().getName() + "  ends. ") ;
	} // end main

	
}
