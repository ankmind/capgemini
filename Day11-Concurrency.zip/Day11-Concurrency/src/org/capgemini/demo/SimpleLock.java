package org.capgemini.demo;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SimpleLock implements Runnable{
	
	private Lock mylock;
	private Account account;
	private final int balance=100;
	
	
	public SimpleLock(){
		this.account=new Account(balance);
		mylock=new ReentrantLock(true);
		
		
	}


	@Override
	public void run() {
		
		for(int i=0;i<50;i++)
			makeWithDraw(i);
	}
	
	
	public void makeWithDraw(int amount){
		
		
		//Critical area
		mylock.lock();
		
		String tName=Thread.currentThread().getName();
		
		if(account.getBalance()<0)
			System.out.println(tName + " Amount OverDrawn...");
		else if(account.getBalance()<amount)
			System.out.println(tName +" Insufficient Balance...");
		else
		{
			account.withDraw(amount);
			System.out.println(tName + " Updated Balance : " + account.getBalance());
		}
		
		mylock.unlock();//End
		
	}
	

}
