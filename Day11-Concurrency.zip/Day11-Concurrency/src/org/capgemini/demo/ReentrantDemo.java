package org.capgemini.demo;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantDemo extends Thread{

	private int value;
	ReentrantLock myLock;
	
	public ReentrantDemo(){
		myLock=new ReentrantLock();
	}
	
	
	public void run(){
		setValue(15);
	}
	
	
	public void setValue(int incVal){
		myLock.lock();
		
		String tName=Thread.currentThread().getName();
		
		System.out.println(tName + " Holds " + myLock.getHoldCount() + " Locks, Begining");
		
		this.value+=incVal;
		
		showCount();
		
		
		//myLock.tryLock(5, TimeUnit.SECONDS);
		
		System.out.println(tName + " Holds " + myLock.getHoldCount() + " Locks, Ending");
		
		myLock.unlock();
		
		
		System.out.println(tName + " Holds " + myLock.getHoldCount() + "End....");
		
	}
	
	
	public void showCount(){
		myLock.lock();
		
		String tName=Thread.currentThread().getName();
		
		System.out.println(tName + " Holds, inside ShowCount " + myLock.getHoldCount() + " Locks, Begining");
		
		
		System.out.println("Incremented Value:" + this.value);
		System.out.println(tName + " Holds, end of ShowCount" + myLock.getHoldCount() + " Locks, Begining");
		
		myLock.unlock();
		
		System.out.println(tName + " Holds " + myLock.getHoldCount() + "End of ShowCount....");
		
	}
	
	
}
