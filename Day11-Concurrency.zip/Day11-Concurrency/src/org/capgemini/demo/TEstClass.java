package org.capgemini.demo;

public class TEstClass {

	public static void main(String[] args) {
		
		ReentrantDemo myThread=new ReentrantDemo();
		myThread.start();
		//System.out.println("\n\n\n\n");
		
		/*ReentrantDemo myThread1=new ReentrantDemo();
		myThread1.start();
		*/
	}

}
