package org.capgemini;

public class Employee {

	
	//instance varibles
	int empid=1001;
	String empName="Jack";
	double salary=34000;
	boolean isPermanent=true;
	
	
	
	public int addNums(final int num1,int num2){
		//num1=700;
		num2=900;
		return num1+num2;
	}
	
	
	
	
	//instance Method
	public void showEmployee(){
		//Local variable
		int count=100;
		final int COMPANYID=1009;
		
		System.out.println("Count:"  +count);
		
		System.out.println("Emp Name:"  + empName);
		System.out.println("Emp Id:" + empid);
		System.out.println("Salary:"  +salary);
		System.out.println("Is Permament?" + isPermanent);
		
		//companyId=1000;
		
		System.out.println("Company Id: " +COMPANYID);
	}
	
	

	
	
	public static void main(String[] args) {

		//System.out.println("Hello World!!!");
		
		int sum;
		
		//System.out.println(sum);
		
		Employee emp=new Employee();
		System.out.println(emp.addNums(100, 300));
		emp.showEmployee();
		
		//System.out.println(emp);
		
		
	}
	
	

}
