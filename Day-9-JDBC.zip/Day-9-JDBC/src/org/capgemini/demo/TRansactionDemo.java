package org.capgemini.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Types;

public class TRansactionDemo {

	public static void main(String[] args) {
		Savepoint s1=null,s2=null;
		
		Connection conn=null;
		try {
			//Load Driver Class
			Class.forName("oracle.jdbc.OracleDriver");
			
			
			//Establish connection
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
			
		
			conn.setAutoCommit(false);
			
			
			
			
			
			
			s1=conn.setSavepoint("s1");
			
			
			
			
			
			
			
			
			s2=conn.setSavepoint("s2");
			
			
			
			
			
			
			
			
			conn.commit();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			
			try {
				conn.rollback(s2);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} catch (SQLException e) {
			
			
			try {
				conn.rollback(s1);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			//Close Connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
