package org.capgemini.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class TEstMestINfo {

	public static void main(String[] args) {

		Connection conn=null;
		try {
			//Load Driver Class
			Class.forName("oracle.jdbc.OracleDriver");
			
			
			//Establish connection
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
			
		
			String sql="select * from employees";
			
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery(sql);
			
			
			ResultSetMetaData rsmetadata=rs.getMetaData();
			
			System.out.println(rsmetadata.getColumnCount());
			System.out.println(rsmetadata.getColumnName(3));
			
			System.out.println(rsmetadata.getColumnTypeName(3));
			
			
			
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			//Close Connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
