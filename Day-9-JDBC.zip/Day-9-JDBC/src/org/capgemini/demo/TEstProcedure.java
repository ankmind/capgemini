package org.capgemini.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

public class TEstProcedure {

	public static void main(String[] args) {
		
		
		Connection conn=null;
		try {
			//Load Driver Class
			Class.forName("oracle.jdbc.OracleDriver");
			
			
			//Establish connection
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
			
			
			int empid=555;
			String outempName;
			double outempSalary;
			
			//Callable
			
			CallableStatement procall=conn.prepareCall("{call find_emp(?,?,?)}");
			
			procall.setInt(1, empid);
			procall.registerOutParameter(2, Types.VARCHAR);
			procall.registerOutParameter(3, Types.NUMERIC);
			
			procall.execute();
			
			outempName=procall.getString(2);
			outempSalary=Double.parseDouble(procall.getBigDecimal(3).toString());
			
			System.out.println("Employee Name:" + outempName);
			System.out.println("Employee Salary:" + outempSalary);
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			//Close Connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
