package org.capgemini.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestJDBC {

	public static void main(String[] args) {
		Connection conn=null;
		try {
			//Load Driver Class
			Class.forName("oracle.jdbc.OracleDriver");
			
			
			//Establish connection
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
			
			//Create statement to execute Query
		//	Statement stmt=conn.createStatement();
			
			
			//DQL
			/*//String sql="select * from employees where salary>50000";
			String sql="select a.aid,a.aname,avg(salary) from certified c, aircraft a, employees e where c.aid=a.aid and c.eid=e.eid group by a.aname,a.aid";
			ResultSet rs=stmt.executeQuery(sql);
			
			//Manage Result Set
			while(rs.next()){
				System.out.println(rs.getInt(1)+"\t" + rs.getString(2) + "\t" + rs.getDouble(3));
			}*/
			
		
			int eid=223;
			String ename="Harish";
			double sal=78000;
			
			//DML
			//String sql="insert into employees values(?,?,?)";
			
			String sql="update employees set ename=?,salary=? where eid=?";
			//int count=stmt.executeUpdate(sql);
			PreparedStatement ps=conn.prepareStatement(sql);
			
		
			ps.setString(1, ename);
			ps.setDouble(2, sal);
			ps.setInt(3, eid);
			
			int count=ps.executeUpdate();
			
			if(count>0)
				System.out.println("Record INserted");
			else
				System.out.println("Insertion Failure ");
			
			
			
		/*	
			String mytable="create table mytable_info1(myid int primary key,myname varchar(25) not null)";
			PreparedStatement ps=conn.prepareStatement(mytable);
			
			boolean flag=ps.execute();
			
			
			if(!flag)
				System.out.println("Table created");
			else
				System.out.println("Table Creation Error!");*/
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			//Close Connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

}
