package org.capgemini.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class BatchDemo {

	public static void main(String[] args) {
		Connection conn=null;
		try {
			//Load Driver Class
			Class.forName("oracle.jdbc.OracleDriver");
			
			
			//Establish connection
			conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
			
		
			
			String sql="insert into employees values(6001,'AAAA',45000)";
			String sql1="insert into employees values(6002,'BBB',4000)";
			String sql2="insert into employees values(6003,'CCCC',67000)";
			String sql3="insert into employees values(6004,'DDD',9900)";
			String sql4="insert into employees values(6005,'FFFF',1200)";
			String sql5="insert into employees values(6006,'SSSS',5670)";
			
		
			Statement stmt=conn.createStatement();
			stmt.addBatch(sql);
			stmt.addBatch(sql1);
			stmt.addBatch(sql2);
			stmt.addBatch(sql3);
			stmt.addBatch(sql4);
			stmt.addBatch(sql5);
			
			
			int[] result=stmt.executeBatch();
			
			for(int res:result)
				System.out.println(res);
			
			
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			//Close Connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

}
