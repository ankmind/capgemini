package org.capgemini;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class showEmployee
 */
public class showEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		
		String empId=request.getParameter("empId");
		String empFirstName=request.getParameter("empFirstName");
		String emplastName=request.getParameter("emplastName");
		
		String empSalary=request.getParameter("empSalary");
		String address=request.getParameter("address");
		String gender=request.getParameter("gender");
		
		
		
		String[] depart=request.getParameterValues("department");
		
		String department="";
		for(String dep:depart)
			department+=dep +",";
		
		
		//department=department.replace(department.charAt(department.lastIndexOf(",")),' ');
		department=department.substring(0, department.length()-1);
		
		String edob=request.getParameter("empDob");
		
		
		if(empId.equals("111"))
			response.sendRedirect("pages/home.html");
		
		else{
		out.println("Employee Id: " + empId  );
		out.println("Employee FirstName: " + empFirstName );
		out.println("Employee LastName: " + emplastName  );
		out.println("Employee Salary: " + empSalary  );
		out.println("Employee Address: " + address  );
		out.println("Employee Gender: " + gender  );
		out.println("Employee Department: " + department  );
		out.println("Employee DOB: " + edob  );
		}
	}

}
