

function displaySalary(){
	
	var sal=myForm.empSalary.value;
	
	document.getElementById("sal").innerHTML=sal;
			
}