package org.capgemini.demo;

public class TEstClass {

	public static void main(String[] args) {
	
		/*Account account=new Account();
		System.out.println(account.balance);
		
		System.out.println(account.custId);
		*/
		
		Employee emp=new Employee();
		System.out.println(emp.getEmpId());
		
		Employee emp1=new Employee(1001,"Tom",2300,45);
		System.out.println(emp1.getEmpId());
		
		
		Employee emp2=new Employee(134,"Jerry");
		System.out.println(emp2.getEmpId());
		
		
		System.out.println(emp2.count);
		
		//emp2.printCount();
		
		Employee.showDetails();
		
		
	}

}
