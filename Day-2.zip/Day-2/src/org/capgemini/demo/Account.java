package org.capgemini.demo;

public class Account {
	
	private int accountNo;
	public String accountName;
	protected double balance;
	int custId;
	
	
	

}
