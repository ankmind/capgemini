package org.capgemini.demo;

import org.capgemini.Customer;

public class Employee {
	
	private int empId;
	private String empName;
	private double salary;
	private int age;
	
	{
		System.out.println("Normal Block");
	}
	
	
	
	public static int count;
	
	static
	{
		System.out.println("Static Block");
		System.out.println("Count :" + count);
	}
	
	
	
	public Employee(){
		count++;
		System.out.println("Default Constructor");
	}
	
	
	public Employee(int empId,String empName){
		count++;
		System.out.println("Overloaded Constructor");
		this.empId=empId;
		this.empName=empName;
	}
	
	
	public Employee(int empId,String ename,double salary,int age){
		
		this(empId,ename);
		//count++;
		System.out.println("Constructor Oveloaded");
		/*this.empId=empId;
		this.empName=ename;
		*/
		this.salary=salary;
		this.age=age;
	}
	
	//getter
	public int getEmpId(){
		return empId;
	}
	
	
	public void printCount(){
		System.out.println("EmpId:"+empId);
		System.out.println("No of Object Count:" + count);
	}
	
	//setter
	public void setEmpId(int empId){
		this.empId=empId;
	}

	
	
	
	
	public static void showDetails(){
		int count=100;
		System.out.println("Count :"  +Employee.count);
		System.out.println("Count :" +count);
		
		Customer customer=new Customer();
		
	}
	
	
	
	
	
	
	
	
	
	
}
