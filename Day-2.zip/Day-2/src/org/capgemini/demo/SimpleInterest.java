package org.capgemini.demo;

public class SimpleInterest {
	
	
	private double prin=5000;
	private float rate=3.5f;
	private int year=3;
	
	
	public double calcuateInterest(){
		return prin*rate*year;
	}
	
	/*public double calcuateInterest(int prin,int year){
		return prin*rate*year;
	}
	*/
	
	public double calcuateInterest(double prin){
		System.out.println("With Prin Amount");
		
		return prin*rate*year;
	}
	
	public double calcuateInterest(float prin,int year){
		System.out.println("With Prin Amount and year");
		
		return prin*rate*year;
	}
	
	
	public double calcuateInterest(int prin,float year){
		System.out.println("With Prin Amount and year");
		
		return prin*rate*year;
	}
	
	
	
	
	
	
	
	

	public static void main(String[] args) {
		SimpleInterest simin=new SimpleInterest();
		System.out.println(simin.calcuateInterest());
		System.out.println(simin.calcuateInterest(23000));
		System.out.println(simin.calcuateInterest(2300f,5));
	}

}
