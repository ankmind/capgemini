package org.capgemini;

import static org.capgemini.demo.Employee.*;

public class TEstClass1 {

	public static void main(String[] args) {
		showDetails();

		System.out.println("Count:" +  count);
	}

}
