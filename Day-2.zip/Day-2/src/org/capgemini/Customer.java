package org.capgemini;

public class Customer {
	
	
	/**/
	
	
	int custId=1001;
	String custName="Tom";
	CustomerType custType=CustomerType.DIAMOND;
	
	

}

