package org.capgemini.arrdemo;

public class ArrayDemo {

	public static void main(String[] args) {
		
		//Customer[] myarr=new Customer[5];
		
		Customer customer=new Customer(100, "Tom", 4500);
		Customer customer1=new Customer(123, "Jerry", 3400);
		Customer customer2=new Customer(190, "RamSingh", 1500);
		Customer customer3=new Customer(191, "JAck", 2300);
		Customer customer4=new Customer(189, "Hari", 1000);
		
		//myarr[0]=customer;
		
		Customer[] myarr={customer,customer1,customer2,customer3,customer4};
		
		
		for(Customer cust : myarr)
			System.out.println(cust);
		
		
	}

}
