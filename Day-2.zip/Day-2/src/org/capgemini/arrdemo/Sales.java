package org.capgemini.arrdemo;

public class Sales extends Customer{
	
	private int transId;
	private String productName;
	private int quantity;
	
	
	public Sales(){}
	
	public Sales(int custId,String custName,double fees,int transId,String pnname, int qty){
		super(custId,custName,fees);
		
		this.transId=transId;
		this.productName=pnname;
		this.quantity=qty;
	}
	
	
	
	public void showTRansactionDetails(){
		System.out.println("Customer Id:" + custId);
		System.out.println("Customer Name:" + custName);
		System.out.println("RegFees:" + regFees);
	}

	
	
	@Override
	public void show(){
		super.show();
		System.out.println("Sales Class Method");
	}
	
	
	public void show(int num){
		System.out.println("Num:" + num);
	}
	
	
	
	/*public static void main(String[] args){
		//Customer customer=new Customer();
		Sales sales=new Sales(123,"Tom",3400,1,"Product1",10);
		
		Customer customer=new Sales(100,"Jerry",1200,2,"product2",3);
		
		sales.showTRansactionDetails();
		System.out.println(sales.getCustId());
		
		
		//customer.showTRansactionDetails();
		
		System.out.println(customer.getCustId());
		
		sales.show();
		
		
		customer.show();
		
		
		
		
	}
	*/
	
}
