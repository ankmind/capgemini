package org.capgemini.arrdemo;

public class Customer {
	
	
	protected int custId;
	protected String custName;
	double regFees;
	
	public Customer(){
		
	}
	
	
	
	public Customer(int custId, String custName, double regFees) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.regFees = regFees;
	}



	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getRegFees() {
		return regFees;
	}
	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}

	
	public void show(){
		System.out.println("Customer Method");
	}
	
	
	
	
	
	
	
	
	
	
	
	


	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName
				+ ", regFees=" + regFees + "]";
	}
	
	/*public String toString(){
		return "Customer -->" + custId +"," +custName +", " + regFees;
	}
	*/
	
	
	

}
