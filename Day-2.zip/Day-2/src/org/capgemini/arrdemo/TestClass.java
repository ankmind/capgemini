package org.capgemini.arrdemo;

public class TestClass {

	public static void main(String[] args) {
	
		Payment payment=new Payment();
		
		
		
	}

}
