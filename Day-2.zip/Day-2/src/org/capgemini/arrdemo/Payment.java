package org.capgemini.arrdemo;

public class Payment extends Sales {

	private int receiptNo;
	private double amount;
	
	
	public Payment(){
		
	}
	
	public Payment(int receiptNo,double amount){
		super();
		this.receiptNo=receiptNo;
		this.amount=amount;
	}
	
	
	
	
	
	public int getReceiptNo() {
		return receiptNo;
	}
	public void setReceiptNo(int receiptNo) {
		this.receiptNo = receiptNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	
	
	
	
	
	
	
}
