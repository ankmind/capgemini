package org.capgemini.mydemo;

import org.capgemini.demo.Account;

public class MainClass {

	public static void main(String[] args) {
		
		Account account=new Account();
		//System.out.println(account.custId);
		
		
	}

}
