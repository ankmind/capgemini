package org.capgemini;

public class TestClass {

	public static void main(String[] args) {
	
		CustomerType[] cType=CustomerType.values();
	
		for(CustomerType type : cType)
			System.out.println(type + " Value :" + type.getMinValue() + "-->" +type.getMaxValue() );
		
	}

}
