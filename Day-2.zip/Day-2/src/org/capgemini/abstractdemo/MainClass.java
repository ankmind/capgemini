package org.capgemini.abstractdemo;

public class MainClass {

	public static void main(String[] args) {
	
		Shape rect=new Rectangle();
		rect.drawShape();
		rect.fillShape();
		
		
		
	}

}
