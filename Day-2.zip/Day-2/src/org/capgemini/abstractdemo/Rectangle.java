package org.capgemini.abstractdemo;

public class Rectangle extends Shape{

	
	public Rectangle() {
		System.out.println("No Arg Cons - Rectangle");
	}
	
	@Override
	public void drawShape() {
		System.out.println("Draw Rectange Shape");
	}

	@Override
	public void fillShape() {
		System.out.println("Fill Rectangle Shape");
	}
	
	

}
