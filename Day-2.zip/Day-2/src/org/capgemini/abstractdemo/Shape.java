package org.capgemini.abstractdemo;

abstract public class Shape {

	public Shape(){
		super();
		System.out.println("Shape no-arg cons");
	}
	
	public void nonAbstractMethod(){
		System.out.println("Non Abstract method");
	}
	
	
	abstract public void drawShape();
	abstract public void fillShape();
	
	
}
