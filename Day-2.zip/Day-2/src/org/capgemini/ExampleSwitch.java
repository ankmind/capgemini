package org.capgemini;



public class ExampleSwitch {

	public static void main(String[] args) {
		
		char ch=49;
		
		switch(ch){
		/*default:
			
			System.out.println("Other colors");
		*/	
		
		case 'r':
		case 'R':
			System.out.println("Red");
			break;
		
		case 'g':
			System.out.println("Green");
			break;
		
			
		case 'b':
			System.out.println("Blue");
			break;
			
		
		
			
		}
		
		
		
		
		
		CustomerType ctype=null;
		
		switch(ctype){
		case DIAMOND:
			System.out.println("DIAMOND Customer");
			break;
		case SILVER:
			System.out.println("SILVER customer");
			break;
		default:
			System.out.println("No Type Specified");
		}
		
	}

}
