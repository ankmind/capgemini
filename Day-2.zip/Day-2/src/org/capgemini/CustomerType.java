package org.capgemini;

public enum CustomerType {

		
		SILVER(0,100),GOLD(101,300),DIAMOND(301,400),PLAGTINUM(401,500);
		
		int minvalue;
		int maxvalue;
		
		private CustomerType(int minvalue,int maxvalue) {
			this.minvalue=minvalue;
			this.maxvalue=maxvalue;
		}
		
		
		public int getMinValue(){
			return minvalue;
		}

		public int getMaxValue(){
			return maxvalue;
		}
		
	}



