package org.capgemini.demo;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.channels.CompletionHandler;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
 
public class AsynchronousFileWriteExample {
 
   
    public static void main(String[] args) {
        Path file = null;
        AsynchronousFileChannel asynchFileChannel = null;
        String filePath= "D:\\vidavid\\Training\\2015\\Barclays\\Demo\\Day12-FILEIO\\src\\org\\capgemini\\demo\\FileDemo.java";
        try {
            file = Paths.get(filePath);
            asynchFileChannel = AsynchronousFileChannel.open(file,
                    StandardOpenOption.WRITE,
                    StandardOpenOption.CREATE);
 
            CompletionHandler<Integer, Object> handler = new CompletionHandler<Integer, Object>() {
                @Override
                public void completed(Integer result, Object attachment) {
                    System.out.println("Thread: "+ Thread.currentThread().getName()+" File Write Completed with Result:"
                            + result);
                }
 
                @Override
                public void failed(Throwable e, Object attachment) {
                    System.err.println("File Write Failed Exception:");
                    e.printStackTrace();
                }
            };
            System.out.println("Thread: "+Thread.currentThread().getName()+" Before write call");
            asynchFileChannel.write(ByteBuffer.wrap("I am writing using Asynchronous NIO.".getBytes()),
                    						10, "File Write", handler);
            
            
            System.out.println("Thread: "+Thread.currentThread().getName()+" After write call");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                asynchFileChannel.close();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
 
}
