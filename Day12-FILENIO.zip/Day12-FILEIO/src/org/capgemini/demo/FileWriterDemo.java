package org.capgemini.demo;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileWriterDemo {

	public static void main(String[] args) {
	
		Path file=Paths.get("D:\\vidavid\\fileINfo\\niodemo.txt");
		BufferedWriter buff=null;
		
		try {
			file=Files.createFile(file);
		
		
			String myData="I am working in NIO!";
	
			buff=Files.newBufferedWriter(file, Charset.forName("UTF-8"));
			
			
			buff.write(myData);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try {
				buff.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		
	}

}
