package org.capgemini.demo;

public class varargDemo {

	public static void main(String[] args) {
		varargDemo demo=new varargDemo();
		demo.myMethod("one","two","three");
	}
	
	
	public void myMethod(String...arg){
		for(String s:arg){
			System.out.println(s);
		}
	}

}
