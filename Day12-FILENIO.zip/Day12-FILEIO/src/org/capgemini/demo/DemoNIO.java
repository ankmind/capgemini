package org.capgemini.demo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;

public class DemoNIO {

	public static void main(String[] args) {
		RandomAccessFile file=null;
		
		try {
			file=new RandomAccessFile("D:\\vidavid\\Training\\2015\\Barclays\\Demo\\Day12-FILEIO\\src\\org\\capgemini\\demo\\FileDemo.java", "r");
			FileChannel fileChannel=file.getChannel();
			ByteBuffer buffer=ByteBuffer.allocate(100);
			
			int bytes=fileChannel.read(buffer);
			
			System.out.println(bytes);
			
			
			
			while(bytes!=-1){
				 buffer.flip();
				
				 for(int i=0;i<bytes;i++)
				 System.out.print((char)buffer.get());
				
				 buffer.clear();
				
				 
				 bytes=fileChannel.read(buffer);
				 System.out.println(bytes);
				 
			}
					
			
			System.out.println(bytes);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
