package org.capgemini.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileBufferedRader {

	public static void main(String[] args) {
		Path file=Paths.get("D:\\vidavid\\fileINfo\\niodemo.txt");
		BufferedReader buffReader=null;
		
		try {
			buffReader=Files.newBufferedReader(file);
			
			System.out.println(buffReader.readLine());
			
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				buffReader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
